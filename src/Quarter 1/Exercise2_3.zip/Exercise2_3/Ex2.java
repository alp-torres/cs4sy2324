/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercise2_3;

/**
 *
 * @author TRUTH
 */
public class Ex2 {
    public static void main(String[] args){
        //TODO code application logic here
        Song song1 = new Song("Song Title 1", "Artist 1", "Playlist 1");
        Song song2 = new Song("Song Title 2", "Artist 2", "Playlist 2");
        
        Singer singer1 = new Singer("MJ");
        Singer singer2 = new Singer("Bruno");
        
        singer1.changeFavSong(song1);
        singer2.changeFavSong(song2);
        
        
        singer1.performForAudience(12);
        singer2.performForAudience(10);
        singer1.performForAudience(17, singer2);
        
        System.out.println("Singer: " + singer1.getName());
        System.out.println("Favorite Song: " + singer1.getFavoriteSong().getTitle());
        System.out.println("Performances: " + singer1.getNoOfPerformances());
        System.out.println("Earnings: " + singer1.getEarnings() + "Dollars");
        
        System.out.println("Singer: " + singer2.getName());
        System.out.println("Favorite Song: " + singer2.getFavoriteSong().getTitle());
        System.out.println("Performances: " + singer2.getNoOfPerformances());
        System.out.println("Earnings: " + singer2.getEarnings() + "Dollars");
    }
}
