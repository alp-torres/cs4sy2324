/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercise2_3;

/**
 *
 * @author TRUTH
 */
public class Singer {
    private String name;
    private int noOfPerformances;
    private double earnings;
    private Song favoriteSong;
    private static int totalPerformances = 0;
    
    public Singer(String name){
        this.name = name;
        this.noOfPerformances = 0;
        this.earnings = 0;
        this.favoriteSong = null;
    }
        
    public void performForAudience(int noOfPeople){
        noOfPerformances++;
        earnings += noOfPeople * 100;
        totalPerformances++;
    }
    
    //Overload performForAudience
    public void performForAudience(int noOfPeople, Singer partner){
        int totalAudience = noOfPeople + 1;
        double profitOfSingers = (noOfPeople *100)/2;
        earnings += profitOfSingers;
        partner.earnings += profitOfSingers;
        noOfPerformances++;
        partner.noOfPerformances++;
        totalPerformances++;
    }
    
    //getter and setter method
    public void changeFavSong (Song newFavSong){
        favoriteSong = newFavSong;
    }
    
    public String getName(){
        return name;
    }
    
    public int getNoOfPerformances(){
        return noOfPerformances;
    }
    
    public double getEarnings(){
        return earnings;
    }
    
    public Song getFavoriteSong(){
        return favoriteSong;
    }
    
    public static int getTotalPerformances(){
        return totalPerformances;
    }
}

    

