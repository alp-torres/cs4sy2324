/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercise2_3;

/**
 *
 * @author TRUTH
 */
public class Song {
    private String title;
    private String artist;
    private String playlist;
    
    public Song (String title, String artist, String playlist){
        this.title = title;
        this.artist = artist;
        this.playlist = playlist;
    }
    
    //getter and setter method
        public String getTitle(){
            return title;
        }
        public String getArtist(){
            return artist;
        }
        public String getPlaylist(){
            return playlist;
        }
}

