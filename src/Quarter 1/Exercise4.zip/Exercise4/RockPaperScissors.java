

import java.util.Scanner;

public class RockPaperScissors{
	public static void main(String[] args){
		Move rock = new Move("Rock");
		Move paper = new Move("Paper");
		Move scissors = new Move("Scissors");
		
		rock.setStrongAgainst(scissors);
		paper.setStrongAgainst(rock);
		scissors.setStrongAgainst(paper);
		
		int roundsToWin = 2;
                int playerScore = 0;
                int computerScore = 0;
                Move[] moves = {rock, paper, scissors};      
		
        while (true) {        
		System.out.println("Hello, may we introduce to you: Rock, Paper, Scissors. Please select option:");
                        System.out.println("1.) Start the Game");
                        System.out.println("2.) Change number of rounds to win");
                        System.out.println("3.) Exit the Game");
        
                         int choice;
                         Scanner scan1 = new Scanner(System.in);
                         choice = scan1.nextInt();
                          switch (choice) {
                case 1:
                    System.out.println("This game will be first to " + roundsToWin + " .");
                    playerScore = 0;
                    computerScore = 0;
                    do {
                    int computerChoice = (int) Math.floor(Math.random() * 3) + 1;
                    
                    System.out.println("Select your move:");
                        for (int i = 0; i < moves.length; i++) {
                            System.out.println((i + 1) + ". " + moves[i].getName());
                        }
                        int playerChoice;
                        Scanner scan2 = new Scanner(System.in);
                        playerChoice = scan2.nextInt();
                        Move playerMove = moves[playerChoice - 1];
                        Move computerMove = moves[computerChoice - 1];
                        
                        if (playerChoice <= 1 && playerChoice >= 3){
                            System.out.println("Player chose " + playerMove.getName() + ". Computer chose " + computerMove.getName());
                        } else {
                            System.out.println("Invalid choice. Re-input please.");
                        }
                        
                        int result;
                    result = Move.compareMoves(playerMove, computerMove);
                     System.out.println("Player chose " + playerMove.getName() + ". Computer chose "
                                    + computerMove.getName());
                    switch (result) {
                        case 0:
                            System.out.println("The Player wins this round!");
                            playerScore++;
                            break;
                        case 1:
                            System.out.println("The Computer wins this round!");
                            computerScore++;
                            break;
                        default:
                            System.out.println("The round is tied! No one gets a point.");
                            break;
                        }
                    
                    
                    System.out.println("Player: " + playerScore + " - Computer: " + computerScore);
                    
                            if (playerScore > computerScore) {
                        System.out.println("Player wins!");
                    } else if (computerScore > playerScore) {
                        System.out.println("Computer wins!");
                        
                    }
                          
                             
                            
                        
                    } while (playerScore < roundsToWin && computerScore < roundsToWin);
                        
                    break;

                    case 2:
                        
                        System.out.println("How many wins are needed to win a match?");
                        Scanner scan3 = new Scanner(System.in);
                        roundsToWin = scan3.nextInt();
                        System.out.println("New setting has been saved!");
                        break;

    

                case 3:
                    System.out.println("Thank you for playing!");
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid option. Please choose again.");
                    break;
                    }
                          
                    
                  
                          }
        }


    }


        

                    
                    
                    
        

	
